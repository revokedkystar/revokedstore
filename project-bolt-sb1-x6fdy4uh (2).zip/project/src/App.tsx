import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import Projects from './components/Projects';
import Support from './components/Support';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-black text-white font-['VT323']">
      <Navbar />
      <Hero />
      <Services />
      <Projects />
      <Support />
      <Footer />
    </div>
  );
}

export default App;