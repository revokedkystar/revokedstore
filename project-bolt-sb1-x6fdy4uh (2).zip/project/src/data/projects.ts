import { Project } from '../types';

export const projects: Project[] = [
  {
    id: '1',
    title: 'Discord Community Server',
    description: 'A fully featured Discord community server with custom roles, channels, and moderation systems for enhanced user engagement.',
    icon: 'Users',
    technologies: ['Discord.js', 'Node.js', 'MongoDB', 'Bot Integration'],
    liveUrl: 'https://discord.gg/revoked',
    category: 'other',
    featured: true
  },
  {
    id: '2',
    title: 'Discord Bot',
    description: 'Custom Discord bot with advanced moderation features, music commands, and automated server management capabilities.',
    icon: 'Bot',
    technologies: ['Discord.js', 'Node.js', 'SQLite', 'API Integration'],
    githubUrl: 'https://gist.github.com/revokedkystar/360cd999e4c14cbcdf4df894228bd451',
    category: 'other',
    featured: true
  },
  {
    id: '3',
    title: 'NHS Graphic Design Poster',
    description: 'Professional graphic design poster created for the NHS, focusing on health awareness and public information campaigns.',
    icon: 'Palette',
    technologies: ['Adobe Illustrator', 'Photoshop', 'InDesign', 'Typography'],
    category: 'design',
    featured: true
  },
  {
    id: '4',
    title: 'WebDev Portfolio Website',
    description: 'Modern portfolio website showcasing web development skills with responsive design and interactive elements.',
    icon: 'Globe',
    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Vite'],
    liveUrl: 'https://example-portfolio.com',
    githubUrl: 'https://github.com/username/portfolio',
    category: 'web',
    featured: false
  },
  {
    id: '5',
    title: 'Programming Examples',
    description: 'Collection of programming examples and code snippets demonstrating various algorithms and development patterns.',
    icon: 'Code',
    technologies: ['JavaScript', 'Python', 'React', 'Node.js'],
    githubUrl: 'https://github.com/username/programming-examples',
    category: 'other',
    featured: false
  },
  {
    id: '6',
    title: 'E-commerce Platform',
    description: 'A full-featured e-commerce platform with modern design and secure payment processing. Built with React and Node.js.',
    icon: 'ShoppingCart',
    technologies: ['React', 'Node.js', 'MongoDB', 'Stripe', 'Tailwind CSS'],
    liveUrl: 'https://example-ecommerce.com',
    githubUrl: 'https://github.com/username/ecommerce-platform',
    category: 'web',
    featured: false
  }
];