import { Service } from '../types';

export const services: Service[] = [
  {
    id: '1',
    title: 'Web Development',
    description: 'Custom websites and web applications built with modern technologies',
    icon: 'code',
    features: [
      'Responsive Design',
      'Modern Frameworks (React, Vue, Angular)',
      'Backend Development',
      'Database Integration',
      'API Development',
      'Performance Optimization'
    ],
    price: 'From $50',
    duration: '1-2 weeks'
  },
  {
    id: '2',
    title: 'Discord Bots',
    description: 'Custom Discord bots with advanced features and automation',
    icon: 'bot',
    features: [
      'Custom Commands',
      'Moderation Features',
      'Music & Entertainment',
      'Database Integration',
      'Slash Commands',
      'Auto-moderation'
    ],
    price: 'From $20',
    duration: 'Up to 7 days'
  },
  {
    id: '3',
    title: 'Discord Servers',
    description: 'Complete Discord server setup and management solutions',
    icon: 'users',
    features: [
      'Server Setup & Configuration',
      'Role & Permission Management',
      'Channel Organization',
      'Bot Integration',
      'Community Guidelines',
      'Moderation Systems'
    ],
    price: 'From $15',
    duration: '1-3 days'
  },
  {
    id: '4',
    title: 'Code Review',
    description: 'Professional code review and optimization services',
    icon: 'search',
    features: [
      'Code Quality Analysis',
      'Performance Optimization',
      'Security Assessment',
      'Best Practices Review',
      'Documentation Review',
      'Refactoring Suggestions'
    ],
    price: 'From $15/hour',
    duration: '1-3 days'
  },
  {
    id: '5',
    title: 'Graphic Design',
    description: 'Creative visual design solutions for digital and print media',
    icon: 'palette',
    features: [
      'Logo Design',
      'Brand Identity',
      'Marketing Materials',
      'Social Media Graphics',
      'Print Design',
      'Digital Illustrations'
    ],
    price: 'From $25',
    duration: 'Up to 7 days'
  },
  {
    id: '6',
    title: 'UX Design',
    description: 'User experience design focused on usability and user satisfaction',
    icon: 'layout',
    features: [
      'User Research',
      'Wireframing & Prototyping',
      'User Journey Mapping',
      'Usability Testing',
      'Interface Design',
      'Design Systems'
    ],
    price: 'From $75',
    duration: '2-3 weeks'
  }
];