export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  features: string[];
  price: string;
  duration: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  image?: string;
  icon?: string;
  technologies: string[];
  liveUrl?: string;
  githubUrl?: string;
  category: 'web' | 'mobile' | 'design' | 'other';
  featured: boolean;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: 'services' | 'process' | 'pricing' | 'general' | 'contact';
}