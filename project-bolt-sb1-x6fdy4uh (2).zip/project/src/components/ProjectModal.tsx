import React from 'react';
import { X, ExternalLink, Github } from 'lucide-react';
import * as Icons from 'lucide-react';
import { Project } from '../types';

interface ProjectModalProps {
  project: Project;
  onClose: () => void;
}

const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  const IconComponent = project.icon ? (Icons as any)[project.icon] : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div className="fixed inset-0 bg-black opacity-80" onClick={onClose}></div>
      
      <div className="relative bg-[#1a1a1a] border border-red-600 max-w-2xl w-full 
                    shadow-[0_0_15px_rgba(255,0,0,0.3)] z-50 max-h-[90vh] overflow-y-auto">
        <button 
          className="absolute top-4 right-4 text-gray-400 hover:text-red-600 transition-colors z-10"
          onClick={onClose}
        >
          <X size={20} />
        </button>

        <div className="relative h-64 overflow-hidden bg-[#111] flex items-center justify-center">
          {IconComponent ? (
            <div className="relative">
              <IconComponent size={120} className="text-red-600" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
            </div>
          ) : project.image ? (
            <>
              <img 
                src={project.image} 
                alt={project.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
            </>
          ) : (
            <div className="text-gray-500 text-center">
              <span className="font-['VT323'] text-xl">No Preview Available</span>
            </div>
          )}
          
          <div className="absolute bottom-4 left-6">
            <h3 className="font-['Press_Start_2P'] text-xl text-white mb-2">{project.title}</h3>
            <span className="bg-red-600 text-black font-['VT323'] text-lg px-3 py-1">
              {project.category.toUpperCase()}
            </span>
          </div>
        </div>

        <div className="p-6">
          <p className="font-['VT323'] text-xl text-gray-300 mb-6">{project.description}</p>

          <div className="mb-6">
            <h4 className="font-['VT323'] text-lg text-white mb-3">Technologies Used:</h4>
            <div className="flex flex-wrap gap-2">
              {project.technologies.map((tech, index) => (
                <span 
                  key={index}
                  className="bg-red-900/30 text-red-400 font-['VT323'] text-lg px-3 py-1 border border-red-900/50"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          <div className="flex gap-4">
            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-red-600 text-black font-['VT323'] text-lg px-4 py-3 
                         border border-red-600 hover:bg-transparent hover:text-red-600 
                         transition-all duration-300 flex items-center justify-center"
              >
                <ExternalLink size={18} className="mr-2" />
                VIEW LIVE SITE
              </a>
            )}
            {project.githubUrl && (
              <a
                href={project.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-transparent text-red-600 font-['VT323'] text-lg px-4 py-3 
                         border border-red-600 hover:bg-red-600 hover:text-black 
                         transition-all duration-300 flex items-center justify-center"
              >
                <Github size={18} className="mr-2" />
                VIEW SOURCE CODE
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectModal;