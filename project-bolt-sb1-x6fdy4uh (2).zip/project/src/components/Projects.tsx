import React, { useState } from 'react';
import { projects } from '../data/projects';
import ProjectCard from './ProjectCard';

const Projects: React.FC = () => {
  const [filter, setFilter] = useState<string>('all');

  const categories = ['all', 'web', 'mobile', 'design'];
  const featuredProjects = projects.filter(project => project.featured);
  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(project => project.category === filter);

  return (
    <section id="projects" className="py-20 bg-black">
      <div className="container mx-auto px-4">
        <h2 className="font-['Press_Start_2P'] text-2xl md:text-3xl text-red-600 mb-8 text-center glitch-text-sm">
          MY PROJECTS
        </h2>
        
        {/* Featured Projects */}
        <div className="mb-12">
          <h3 className="font-['Press_Start_2P'] text-lg text-white mb-6 text-center">
            FEATURED WORK
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredProjects.map(project => (
              <ProjectCard key={project.id} project={project} featured />
            ))}
          </div>
        </div>

        {/* All Projects */}
        <div>
          <h3 className="font-['Press_Start_2P'] text-lg text-white mb-6 text-center">
            ALL PROJECTS
          </h3>
          
          <div className="mb-8 flex justify-center">
            <div className="flex flex-wrap gap-2">
              {categories.map(category => (
                <button
                  key={category}
                  className={`px-4 py-2 font-['VT323'] text-lg border ${
                    filter === category 
                      ? 'bg-red-600 text-black border-red-600' 
                      : 'bg-transparent text-gray-400 border-gray-700 hover:border-red-600 hover:text-red-600'
                  } transition-all duration-300`}
                  onClick={() => setFilter(category)}
                >
                  {category.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map(project => (
              <ProjectCard key={project.id} project={project} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;