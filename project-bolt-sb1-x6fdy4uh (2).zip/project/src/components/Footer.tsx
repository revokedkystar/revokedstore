import React from 'react';
import { Code, Palette, Smartphone, Server, Github, Linkedin, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black border-t border-red-900/30 pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div>
            <h3 className="font-['Press_Start_2P'] text-sm text-red-600 mb-4">REVOKED SERVICES</h3>
            <p className="font-['VT323'] text-lg text-gray-400 mb-4">
              MADE BY KYSTAR -- DISCORD.GG/REVOKED FOR SUPPORT!
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-red-600 transition-colors">
                <Github size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-red-600 transition-colors">
                <Mail size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-['Press_Start_2P'] text-sm text-white mb-4">QUICK LINKS</h3>
            <ul className="font-['VT323'] text-lg space-y-2">
              <li><a href="#services" className="text-gray-400 hover:text-red-600 transition-colors">Services</a></li>
              <li><a href="#projects" className="text-gray-400 hover:text-red-600 transition-colors">Projects</a></li>
              <li><a href="#support" className="text-gray-400 hover:text-red-600 transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-['Press_Start_2P'] text-sm text-white mb-4">SERVICES</h3>
            <ul className="font-['VT323'] text-lg space-y-2">
              <li><span className="text-gray-400">Web Development</span></li>
              <li><span className="text-gray-400">Discord Bots</span></li>
              <li><span className="text-gray-400">Discord Servers</span></li>
              <li><span className="text-gray-400">Code Review</span></li>
              <li><span className="text-gray-400">Graphic Design</span></li>
              <li><span className="text-gray-400">UX Design</span></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-['Press_Start_2P'] text-sm text-white mb-4">GET IN TOUCH</h3>
            <p className="font-['VT323'] text-lg text-gray-400 mb-4">
              Contact me via E-mail or Discord.
            </p>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8 pb-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
            <div className="flex items-center">
              <Code size={20} className="text-red-600 mr-3" />
              <span className="font-['VT323'] text-lg text-gray-400">Clean Code</span>
            </div>
            <div className="flex items-center">
              <Palette size={20} className="text-red-600 mr-3" />
              <span className="font-['VT323'] text-lg text-gray-400">Modern Design</span>
            </div>
            <div className="flex items-center">
              <Smartphone size={20} className="text-red-600 mr-3" />
              <span className="font-['VT323'] text-lg text-gray-400">Mobile First</span>
            </div>
            <div className="flex items-center">
              <Server size={20} className="text-red-600 mr-3" />
              <span className="font-['VT323'] text-lg text-gray-400">Scalable Solutions</span>
            </div>
          </div>
          
          <div className="text-center">
            <p className="font-['VT323'] text-gray-600 text-md">
              &copy; {new Date().getFullYear()} Kystar's Portfolio. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;