import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
      scrolled ? 'bg-black/90 shadow-[0_0_10px_rgba(255,0,0,0.5)]' : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <a href="#" className="text-red-600 font-['Press_Start_2P'] text-xl relative">
          <span className="glitch-text">RS</span>
        </a>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          <a href="#services" className="nav-link">SERVICES</a>
          <a href="#projects" className="nav-link">PROJECTS</a>
          <a href="#support" className="nav-link">CONTACT</a>
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-red-600 focus:outline-none"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-black border-t border-red-900/50">
          <div className="container mx-auto px-4 py-2 flex flex-col">
            <a href="#services" className="mobile-nav-link" onClick={() => setIsMenuOpen(false)}>SERVICES</a>
            <a href="#projects" className="mobile-nav-link" onClick={() => setIsMenuOpen(false)}>PROJECTS</a>
            <a href="#faq" className="mobile-nav-link" onClick={() => setIsMenuOpen(false)}>FAQ</a>
            <a href="#support" className="mobile-nav-link" onClick={() => setIsMenuOpen(false)}>CONTACT</a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;