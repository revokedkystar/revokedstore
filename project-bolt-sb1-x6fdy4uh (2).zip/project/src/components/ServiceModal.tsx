import React from 'react';
import { X, MessageSquare, Mail } from 'lucide-react';
import { Service } from '../types';

interface ServiceModalProps {
  service: Service;
  onClose: () => void;
}

const ServiceModal: React.FC<ServiceModalProps> = ({ service, onClose }) => {
  const handleContactClick = (method: 'discord' | 'email') => {
    if (method === 'discord') {
      window.open('https://discord.gg/DEsxx4TdKB', '_blank');
    } else {
      window.location.href = 'mailto:support@revokedservices.com?subject=Quote Request: ' + service.title;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div className="fixed inset-0 bg-black opacity-80" onClick={onClose}></div>
      
      <div className="relative bg-[#1a1a1a] border border-red-600 p-6 max-w-lg w-full 
                    shadow-[0_0_15px_rgba(255,0,0,0.3)] z-50 max-h-[90vh] overflow-y-auto">
        <button 
          className="absolute top-4 right-4 text-gray-400 hover:text-red-600 transition-colors"
          onClick={onClose}
        >
          <X size={20} />
        </button>

        <h3 className="font-['Press_Start_2P'] text-lg text-white mb-2">{service.title}</h3>
        <p className="font-['VT323'] text-xl text-gray-400 mb-6">{service.description}</p>

        <div className="mb-6">
          <h4 className="font-['VT323'] text-lg text-white mb-3">What's Included:</h4>
          <ul className="space-y-2">
            {service.features.map((feature, index) => (
              <li key={index} className="font-['VT323'] text-md text-gray-400 flex items-center">
                <span className="text-red-600 mr-2">▸</span>
                {feature}
              </li>
            ))}
          </ul>
        </div>

        <div className="mb-6 p-4 bg-[#111] border border-red-900/30">
          <div className="flex justify-between items-center mb-2">
            <span className="font-['VT323'] text-lg text-white">Starting Price:</span>
            <span className="font-['Press_Start_2P'] text-sm text-red-600">{service.price}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="font-['VT323'] text-lg text-white">Timeline:</span>
            <span className="font-['VT323'] text-lg text-gray-400">{service.duration}</span>
          </div>
        </div>

        <div className="space-y-3">
          <button
            onClick={() => handleContactClick('discord')}
            className="w-full bg-red-600 text-black font-['VT323'] text-lg px-4 py-3 
                     border border-red-600 hover:bg-transparent hover:text-red-600 
                     transition-all duration-300 flex items-center justify-center"
          >
            <MessageSquare size={18} className="mr-2" />
            DISCUSS ON DISCORD
          </button>
          
          <button
            onClick={() => handleContactClick('email')}
            className="w-full bg-transparent text-red-600 font-['VT323'] text-lg px-4 py-3 
                     border border-red-600 hover:bg-red-600 hover:text-black 
                     transition-all duration-300 flex items-center justify-center"
          >
            <Mail size={18} className="mr-2" />
            SEND EMAIL
          </button>
        </div>

        <div className="mt-6 pt-6 border-t border-red-900/30">
          <p className="font-['VT323'] text-sm text-gray-500 text-center">
            Free consultation • Custom quotes • 24/7 support
          </p>
        </div>
      </div>
    </div>
  );
};

export default ServiceModal;