import React, { useState } from 'react';
import { MessageSquare } from 'lucide-react';
import * as Icons from 'lucide-react';
import { Service } from '../types';
import ServiceModal from './ServiceModal';

interface ServiceCardProps {
  service: Service;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const IconComponent = (Icons as any)[service.icon.charAt(0).toUpperCase() + service.icon.slice(1)];

  return (
    <>
      <div className="bg-[#1a1a1a] border border-red-900/30 rounded-md overflow-hidden 
                    transform transition-all duration-300 hover:scale-105 
                    hover:shadow-[0_0_15px_rgba(255,0,0,0.3)] service-card relative">
        <div className="p-6 flex flex-col h-full">
          <div className="flex items-center mb-4">
            {IconComponent && <IconComponent size={24} className="text-red-600 mr-3" />}
            <h3 className="font-['Press_Start_2P'] text-sm text-white">{service.title}</h3>
          </div>
          
          <div className="mb-4 flex-grow">
            <p className="font-['VT323'] text-lg text-gray-400 mb-4">{service.description}</p>
            
            <div className="mb-4">
              <h4 className="font-['VT323'] text-lg text-white mb-2">Features:</h4>
              <ul className="space-y-1">
                {service.features.slice(0, 3).map((feature, index) => (
                  <li key={index} className="font-['VT323'] text-md text-gray-400 flex items-center">
                    <span className="text-red-600 mr-2">▸</span>
                    {feature}
                  </li>
                ))}
                {service.features.length > 3 && (
                  <li className="font-['VT323'] text-md text-gray-500">
                    +{service.features.length - 3} more features
                  </li>
                )}
              </ul>
            </div>
          </div>
          
          <div className="mt-auto">
            <div className="flex justify-between items-center mb-4">
              <div>
                <span className="font-['Press_Start_2P'] text-red-600 text-sm block">
                  {service.price}
                </span>
                <span className="font-['VT323'] text-gray-400 text-md">
                  {service.duration}
                </span>
              </div>
            </div>
            
            <button 
              onClick={() => setIsModalOpen(true)}
              className="w-full bg-red-600 text-black font-['VT323'] text-lg px-4 py-2 
                       border border-red-600 hover:bg-transparent hover:text-red-600 
                       transition-all duration-300 flex items-center justify-center neon-glow-sm"
            >
              <MessageSquare size={16} className="mr-2" />
              GET QUOTE
            </button>
          </div>
        </div>
        
        <div className="scanlines-small absolute inset-0 pointer-events-none opacity-20"></div>
      </div>

      {isModalOpen && (
        <ServiceModal
          service={service}
          onClose={() => setIsModalOpen(false)}
        />
      )}
    </>
  );
};

export default ServiceCard;