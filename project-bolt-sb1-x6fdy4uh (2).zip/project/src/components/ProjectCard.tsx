import React, { useState } from 'react';
import { ExternalLink, Github, Eye } from 'lucide-react';
import * as Icons from 'lucide-react';
import { Project } from '../types';
import ProjectModal from './ProjectModal';

interface ProjectCardProps {
  project: Project;
  featured?: boolean;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, featured = false }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const IconComponent = project.icon ? (Icons as any)[project.icon] : null;

  return (
    <>
      <div className={`bg-[#1a1a1a] border border-red-900/30 rounded-md overflow-hidden 
                    transform transition-all duration-300 hover:scale-105 
                    hover:shadow-[0_0_15px_rgba(255,0,0,0.3)] project-card relative
                    ${featured ? 'ring-2 ring-red-600/50' : ''}`}>
        
        {featured && (
          <div className="absolute top-2 right-2 z-10">
            <span className="bg-red-600 text-black font-['Press_Start_2P'] text-xs px-2 py-1">
              FEATURED
            </span>
          </div>
        )}

        <div className="relative h-48 overflow-hidden bg-[#111] flex items-center justify-center">
          {IconComponent ? (
            <div className="relative">
              <IconComponent size={80} className="text-red-600" />
              <div className="absolute inset-0 bg-black/50 opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <button
                  onClick={() => setIsModalOpen(true)}
                  className="bg-red-600 text-black font-['VT323'] text-lg px-4 py-2 
                           border border-red-600 hover:bg-transparent hover:text-red-600 
                           transition-all duration-300 flex items-center"
                >
                  <Eye size={16} className="mr-2" />
                  VIEW DETAILS
                </button>
              </div>
            </div>
          ) : project.image ? (
            <>
              <img 
                src={project.image} 
                alt={project.title}
                className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
              />
              <div className="absolute inset-0 bg-black/50 opacity-0 hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <button
                  onClick={() => setIsModalOpen(true)}
                  className="bg-red-600 text-black font-['VT323'] text-lg px-4 py-2 
                           border border-red-600 hover:bg-transparent hover:text-red-600 
                           transition-all duration-300 flex items-center"
                >
                  <Eye size={16} className="mr-2" />
                  VIEW DETAILS
                </button>
              </div>
            </>
          ) : (
            <div className="text-gray-500 text-center">
              <span className="font-['VT323'] text-lg">No Preview</span>
            </div>
          )}
        </div>
        
        <div className="p-6">
          <h3 className="font-['Press_Start_2P'] text-sm text-white mb-2">{project.title}</h3>
          <p className="font-['VT323'] text-lg text-gray-400 mb-4 line-clamp-2">{project.description}</p>
          
          <div className="mb-4">
            <div className="flex flex-wrap gap-1">
              {project.technologies.slice(0, 3).map((tech, index) => (
                <span 
                  key={index}
                  className="bg-red-900/30 text-red-400 font-['VT323'] text-sm px-2 py-1 border border-red-900/50"
                >
                  {tech}
                </span>
              ))}
              {project.technologies.length > 3 && (
                <span className="font-['VT323'] text-sm text-gray-500 px-2 py-1">
                  +{project.technologies.length - 3}
                </span>
              )}
            </div>
          </div>
          
          <div className="flex gap-2">
            {project.liveUrl && (
              <a
                href={project.liveUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-red-600 text-black font-['VT323'] text-lg px-3 py-2 
                         border border-red-600 hover:bg-transparent hover:text-red-600 
                         transition-all duration-300 flex items-center justify-center"
              >
                <ExternalLink size={14} className="mr-1" />
                LIVE
              </a>
            )}
            {project.githubUrl && (
              <a
                href={project.githubUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 bg-transparent text-red-600 font-['VT323'] text-lg px-3 py-2 
                         border border-red-600 hover:bg-red-600 hover:text-black 
                         transition-all duration-300 flex items-center justify-center"
              >
                <Github size={14} className="mr-1" />
                CODE
              </a>
            )}
          </div>
        </div>
        
        <div className="scanlines-small absolute inset-0 pointer-events-none opacity-20"></div>
      </div>

      {isModalOpen && (
        <ProjectModal
          project={project}
          onClose={() => setIsModalOpen(false)}
        />
      )}
    </>
  );
};

export default ProjectCard;